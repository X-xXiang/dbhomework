<!doctype html>
<?php
// 載入資料庫設定檔
require_once('db_config.php');

// 設定資料庫連線參數
$host = "localhost";        // 主機名稱
$username = "text";         // 資料庫使用者
$password = "123456";       // 資料庫密碼
$database = "menagerie";    // 資料庫名稱

// 建立連線
$conn = mysqli_connect($host, $username, $password, $database);

// 檢查連線
if (!$conn) {
    die("連線失敗：" . mysqli_connect_error());
}

// 設定編碼
mysqli_set_charset($conn, "utf8");

/* ========= 1. 表單送出時，處理新增 ========= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') { // 如果是 POST（表單送出）
    // 文字欄位
    $name    = $_POST['name']    ?? '';   // 寵物名稱（必填）
    $owner   = $_POST['owner']   ?? '';   // 主人（必填）
    $species = $_POST['species'] ?? '';   // 物種（必填）

    // 性別，改成 radio，可能是 "m" / "f" / 沒有設定（null）
    $sex     = $_POST['sex']     ?? '';   // 允許空

    // ====== 出生日期，從下拉選單的年/月/日組合 ======
    $birth_year  = $_POST['birth_year']  ?? '';
    $birth_month = $_POST['birth_month'] ?? '';
    $birth_day   = $_POST['birth_day']   ?? '';

    if ($birth_year !== '' && $birth_month !== '' && $birth_day !== '') {
        $birth = sprintf('%04d-%02d-%02d', $birth_year, $birth_month, $birth_day);
    } else {
        $birth = null;
    }

    // ====== 死亡日期，從下拉選單的年/月/日組合（整個可為空） ======
    $death_year  = $_POST['death_year']  ?? '';
    $death_month = $_POST['death_month'] ?? '';
    $death_day   = $_POST['death_day']   ?? '';

    if ($death_year !== '' && $death_month !== '' && $death_day !== '') {
        $death = sprintf('%04d-%02d-%02d', $death_year, $death_month, $death_day);
    } else {
        $death = null;
    }

    // 檢查必填欄位：name / owner / species
    if ($name !== '' && $owner !== '' && $species !== '') {

        // 用 prepared statement 寫入資料
        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO PET (name, owner, species, sex, birth, death)
             VALUES (?, ?, ?, ?, ?, ?)"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "ssssss",
            $name,
            $owner,
            $species,
            $sex,
            $birth,
            $death
        );

        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $error = "name、owner、species 為必填欄位";
    }
}

/* ========= 2. 查詢資料，準備顯示 ========= */
$sql = "SELECT * FROM PET";
$result = mysqli_query($conn, $sql);
?>
<html>
<head>
<meta charset="utf-8">
<title>獸醫:寵物表單</title>
</head>

<body>
<h1>獸醫:寵物表單</h1>

<h2>新增寵物資料</h2>

<?php if (!empty($error)) { ?>
    <p style="color:red;"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p>
<?php } ?>

<form method="post" action="">
    <!-- Name（必填） -->
    <label>
        Name：
        <input type="text" name="name" required>
    </label>
    <br><br>

    <!-- Owner（必填） -->
    <label>
        Owner：
        <input type="text" name="owner" required>
    </label>
    <br><br>

    <!-- Species（必填） -->
    <label>
        Species：
        <input type="text" name="species" required>
    </label>
    <br><br>

    <!-- 性別：改成 radio，可為空（兩個都不選即可） -->
    <label>
        Sex：
        <!-- name 一樣是 sex，兩個 radio 互斥 -->
        <input type="radio" name="sex" value="m"> m
        <input type="radio" name="sex" value="f"> f
        <!-- 不強制 required，這樣就可以不選 -->
    </label>
    <br><br>

    <!-- 出生日期：年 / 月 / 日下拉選單 -->
    <label>
        Birth：
        <select name="birth_year">
            <option value="">年</option>
            <?php
            for ($y = 1990; $y <= 2026; $y++) {
                echo "<option value=\"$y\">$y</option>";
            }
            ?>
        </select>

        <select name="birth_month">
            <option value="">月</option>
            <?php
            for ($m = 1; $m <= 12; $m++) {
                echo "<option value=\"$m\">$m</option>";
            }
            ?>
        </select>

        <select name="birth_day">
            <option value="">日</option>
            <?php
            for ($d = 1; $d <= 31; $d++) {
                echo "<option value=\"$d\">$d</option>";
            }
            ?>
        </select>
    </label>
    <br><br>

    <!-- 死亡日期：年 / 月 / 日下拉選單，可完全不選 -->
    <label>
        Death（可空白）：
        <select name="death_year">
            <option value="">年</option>
            <?php
            for ($y = 1990; $y <= 2026; $y++) {
                echo "<option value=\"$y\">$y</option>";
            }
            ?>
        </select>

        <select name="death_month">
            <option value="">月</option>
            <?php
            for ($m = 1; $m <= 12; $m++) {
                echo "<option value=\"$m\">$m</option>";
            }
            ?>
        </select>

        <select name="death_day">
            <option value="">日</option>
            <?php
            for ($d = 1; $d <= 31; $d++) {
                echo "<option value=\"$d\">$d</option>";
            }
            ?>
        </select>
    </label>
    <br><br>

    <button type="submit">新增</button>
</form>

<hr>

<table width="100%" border="5" cellspacing="15" cellpadding="10">
  <tbody>
    <tr>
      <td>name</td>
      <td>owner</td>
      <td>species</td>
      <td>sex</td>
      <td>birth</td>
      <td>death</td>
    </tr>

    <?php while($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['owner']); ?></td>
            <td><?php echo htmlspecialchars($row['species']); ?></td>
            <td><?php echo htmlspecialchars($row['sex']); ?></td>
            <td><?php echo htmlspecialchars($row['birth']); ?></td>
            <td><?php echo htmlspecialchars($row['death']); ?></td>
        </tr>
    <?php } ?>
  </tbody>
</table>

</body>
</html>