<!doctype html>
<?php
$host = "localhost";
$username = "text";
$password = "123456";
$database = "menagerie";

$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("連線失敗：" . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8");
?>
<html>
<head>
<meta charset="utf-8">
<title>無標題文件</title>
</head>

<body>
<h1>獸醫:寵物表單</h1>
<table width="100%" border="5" cellspacing="15" cellpadding="10">
  <tbody>
    <tr>
      <td>Name</td>
      <td>Owner</td>
      <td>Species</td>
      <td>Sex</td>
      <td>Birth</td>
      <td>Death</td>
    </tr>
	<?php
	  while($row_mysqli_fetch_assoc($result){
	?>
	   <tr>
            <td><?php echo $row['name']; ?></td>
        </tr>
        <?php } ?>
 
  </tbody>
</table>

</body>
</html>