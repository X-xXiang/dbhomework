<!doctype html> <!-- 宣告這個文件是 HTML5 的 DOCTYPE -->
<?php
// 載入資料庫設定檔（通常放共用的帳號密碼等設定）
require_once('db_config.php');

// 設定資料庫連線參數
$host = "localhost";        // 資料庫主機名稱
$username = "text";         // 資料庫使用者
$password = "123456";       // 資料庫密碼
$database = "menagerie";    // 資料庫名稱

// 建立與 MySQL 的連線
$conn = mysqli_connect($host, $username, $password, $database);

// 檢查連線是否成功
if (!$conn) {                             // 如果連線失敗（$conn 為 false）
    die("連線失敗：" . mysqli_connect_error()); // 顯示錯誤訊息並結束程式
}

// 設定與資料庫溝通的編碼為 UTF-8
mysqli_set_charset($conn, "utf8");

// ======================= 工具函式：拆日期字串成 年 / 月 / 日 =======================
function split_date($date_str) {          // 定義函式 split_date，參數是日期字串
    if (empty($date_str)) {               // 如果字串是空的或 null
        return ['', '', ''];              // 回傳三個空字串（年、月、日）
    }
    $parts = explode('-', $date_str);     // 用 - 切開字串成陣列 [年, 月, 日]
    if (count($parts) !== 3) {            // 如果不是 3 個部分
        return ['', '', ''];              // 回傳空（表示無效日期）
    }
    return [(int)$parts[0], (int)$parts[1], (int)$parts[2]]; // 轉成整數後回傳陣列
}

// ======================= 1. 判斷是否進入「修改模式」 =======================

$edit_mode = false;                       // 預設不是修改模式
$edit_data = null;                        // 用來存要修改的那一筆資料，預設為 null

// 修改用的出生 / 死亡日期年、月、日預設為空字串
$edit_birthY = $edit_birthM = $edit_birthD = ''; // 出生年月日（修改表單用）
$edit_deathY = $edit_deathM = $edit_deathD = ''; // 死亡年月日（修改表單用）

// 檢查網址是否有帶 ?edit_id=xxx（需要修改哪一筆）
if (isset($_GET['edit_id'])) {            // 如果 URL 有 edit_id 參數
    $edit_id = (int)$_GET['edit_id'];     // 取得 edit_id 並轉成整數（安全一些）

    // 查詢這一筆資料
    $stmt = mysqli_prepare($conn, "SELECT * FROM PET WHERE id = ?"); // 建立預備語句查詢指定 id
    mysqli_stmt_bind_param($stmt, "i", $edit_id);                    // 綁定整數型別的 id 到 SQL ?
    mysqli_stmt_execute($stmt);                                      // 執行查詢
    $result_edit = mysqli_stmt_get_result($stmt);                    // 取得結果集合
    $edit_data = mysqli_fetch_assoc($result_edit);                   // 取出一筆資料為關聯陣列
    mysqli_stmt_close($stmt);                                        // 關閉預備語句

    if ($edit_data) {                                                // 如果有查到資料
        $edit_mode = true;                                           // 進入修改模式

        // 拆出生日期字串成 年 / 月 / 日 給修改表單用
        list($edit_birthY, $edit_birthM, $edit_birthD) = split_date($edit_data['birth']);

        // 拆死亡日期字串成 年 / 月 / 日 給修改表單用
        list($edit_deathY, $edit_deathM, $edit_deathD) = split_date($edit_data['death']);
    }
}

// ======================= 2. 表單送出時：判斷是新增還是更新 =======================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {        // 如果這次請求是 POST（表單送出）
    $action = $_POST['action'] ?? 'add';            // 從隱藏欄位取得 action，預設是 add（新增）

    // 共同欄位：不論新增/更新都會用到
    $name    = $_POST['name']    ?? '';            // 寵物名稱（必填）
    $owner   = $_POST['owner']   ?? '';            // 主人名稱（必填）
    $species = $_POST['species'] ?? '';            // 物種（必填）
    $sex     = $_POST['sex']     ?? '';            // 性別（radio，可為空字串）

    // 出生日期年 / 月 / 日（由下拉選單送出）
    $birth_year  = $_POST['birth_year']  ?? '';    // 出生年
    $birth_month = $_POST['birth_month'] ?? '';    // 出生月
    $birth_day   = $_POST['birth_day']   ?? '';    // 出生日

    // 三個都有選才組 YYYY-MM-DD，否則設為 null
    if ($birth_year !== '' && $birth_month !== '' && $birth_day !== '') {
        $birth = sprintf('%04d-%02d-%02d', $birth_year, $birth_month, $birth_day); // 組成日期字串
    } else {
        $birth = null;                              // 少任一欄就視為沒填
    }

    // 死亡日期年 / 月 / 日（由下拉選單送出，可全部不選）
    $death_year  = $_POST['death_year']  ?? '';    // 死亡年
    $death_month = $_POST['death_month'] ?? '';    // 死亡月
    $death_day   = $_POST['death_day']   ?? '';    // 死亡日

    // 同樣三個都有選才組日期字串，否則設為 null
    if ($death_year !== '' && $death_month !== '' && $death_day !== '') {
        $death = sprintf('%04d-%02d-%02d', $death_year, $death_month, $death_day); // 組成日期字串
    } else {
        $death = null;                              // 可完全不選，存 null
    }

    // 檢查必填欄位是否都有填
    if ($name === '' || $owner === '' || $species === '') { // 只要有一個空就錯誤
        $error = "name、owner、species 為必填欄位";           // 設定錯誤訊息
    } else {                                                // 三個必填都有填
        if ($action === 'add') {                            // 如果是新增
            // 建立 INSERT 預備語句
            $stmt = mysqli_prepare(
                $conn,
                "INSERT INTO PET (name, owner, species, sex, birth, death)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            // 綁定 6 個字串參數
            mysqli_stmt_bind_param(
                $stmt,
                "ssssss",                                   // 6 個 s = 6 個字串
                $name,
                $owner,
                $species,
                $sex,
                $birth,
                $death
            );
            mysqli_stmt_execute($stmt);                     // 執行 INSERT
            mysqli_stmt_close($stmt);                       // 關閉預備語句

            header("Location: " . $_SERVER['PHP_SELF']);    // 新增後重新導向回本頁
            exit;                                           // 結束程式（避免繼續往下跑）
        } elseif ($action === 'update') {                   // 如果是更新
            $id = (int)($_POST['id'] ?? 0);                 // 從隱藏欄位取得要更新的 id，轉成整數

            // 建立 UPDATE 預備語句
            $stmt = mysqli_prepare(
                $conn,
                "UPDATE PET
                 SET name = ?, owner = ?, species = ?, sex = ?, birth = ?, death = ?
                 WHERE id = ?"
            );
            // 綁定 6 個字串 + 1 個整數（id）
            mysqli_stmt_bind_param(
                $stmt,
                "ssssssi",                                  // 6 字串 + 1 整數
                $name,
                $owner,
                $species,
                $sex,
                $birth,
                $death,
                $id
            );
            mysqli_stmt_execute($stmt);                     // 執行 UPDATE
            mysqli_stmt_close($stmt);                       // 關閉預備語句

            header("Location: " . $_SERVER['PHP_SELF']);    // 更新後回到主畫面（不帶 edit_id）
            exit;                                           // 結束程式
        }
    }
}

// ======================= 3. 讀出全部資料，準備顯示表格 =======================

$sql = "SELECT * FROM PET ORDER BY id ASC"; // SQL 查詢字串：把 PET 表全部撈出依 id 排序
$result = mysqli_query($conn, $sql);        // 執行查詢，把結果放到 $result
?>
<html> <!-- HTML 文件開始 -->
<head> <!-- 頁首區開始 -->
<meta charset="utf-8"> <!-- 設定網頁編碼 -->
<title>獸醫:寵物表單</title> <!-- 瀏覽器分頁標題 -->
</head> <!-- 頁首區結束 -->

<body> <!-- 網頁主體開始 -->
<h1>獸醫:寵物表單</h1> <!-- 主標題 -->

<?php if (!empty($error)) { ?> <!-- 如果有錯誤訊息變數 $error（新增/更新時產生） -->
    <p style="color:red;"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p> <!-- 顯示紅色錯誤訊息 -->
<?php } ?> <!-- if 結束 -->

<!-- ======================= 新增資料的表單 ======================= -->
<h2>新增寵物資料</h2> <!-- 新增表單小標題 -->

<form method="post" action=""> <!-- 新增表單：使用 POST 送回同一頁 -->
    <input type="hidden" name="action" value="add"> <!-- 隱藏欄位：告訴後端這是 add 動作 -->

    <!-- Name（必填） -->
    <label>
        Name：
        <input type="text" name="name" required> <!-- 寵物名稱輸入框 -->
    </label>
    <br><br>

    <!-- Owner（必填） -->
    <label>
        Owner：
        <input type="text" name="owner" required> <!-- 主人名稱輸入框 -->
    </label>
    <br><br>

    <!-- Species（必填） -->
    <label>
        Species：
        <input type="text" name="species" required> <!-- 物種輸入框 -->
    </label>
    <br><br>

    <!-- 性別：radio，可為空 -->
    <label>
        Sex：
        <input type="radio" name="sex" value="m"> m <!-- 選此為公 m -->
        <input type="radio" name="sex" value="f"> f <!-- 選此為母 f -->
        <!-- 不加 required，使用者可以都不選 -->
    </label>
    <br><br>

    <!-- 出生日期：年 / 月 / 日 下拉選單 -->
    <label>
        Birth：
        <select name="birth_year"> <!-- 出生年下拉 -->
            <option value="">年</option> <!-- 空選項，表示未選 -->
            <?php
            for ($y = 1990; $y <= 2026; $y++) {          // 迴圈產出 1990~2026 年
                echo "<option value=\"$y\">$y</option>";  // 輸出 option
            }
            ?>
        </select>

        <select name="birth_month"> <!-- 出生月下拉 -->
            <option value="">月</option> <!-- 空選項 -->
            <?php
            for ($m = 1; $m <= 12; $m++) {               // 1~12 月
                echo "<option value=\"$m\">$m</option>";  // 輸出 option
            }
            ?>
        </select>

        <select name="birth_day"> <!-- 出生日下拉 -->
            <option value="">日</option> <!-- 空選項 -->
            <?php
            for ($d = 1; $d <= 31; $d++) {               // 1~31 日（未分大小月）
                echo "<option value=\"$d\">$d</option>";  // 輸出 option
            }
            ?>
        </select>
    </label>
    <br><br>

    <!-- 死亡日期：年 / 月 / 日 下拉選單，可完全不選 -->
    <label>
        Death（可空白）：
        <select name="death_year"> <!-- 死亡年下拉 -->
            <option value="">年</option> <!-- 空選項 -->
            <?php
            for ($y = 1990; $y <= 2026; $y++) {          // 1990~2026 年
                echo "<option value=\"$y\">$y</option>";  // 輸出 option
            }
            ?>
        </select>

        <select name="death_month"> <!-- 死亡月下拉 -->
            <option value="">月</option> <!-- 空選項 -->
            <?php
            for ($m = 1; $m <= 12; $m++) {               // 1~12 月
                echo "<option value=\"$m\">$m</option>";  // 輸出 option
            }
            ?>
        </select>

        <select name="death_day"> <!-- 死亡日下拉 -->
            <option value="">日</option> <!-- 空選項 -->
            <?php
            for ($d = 1; $d <= 31; $d++) {               // 1~31 日
                echo "<option value=\"$d\">$d</option>";  // 輸出 option
            }
            ?>
        </select>
    </label>
    <br><br>

    <button type="submit">新增</button> <!-- 新增按鈕 -->
</form>

<hr> <!-- 分隔新增表單與下面內容 -->

<!-- ======================= 修改表單（只有在 edit_mode=true 時顯示） ======================= -->
<?php if ($edit_mode && $edit_data) { ?> <!-- 若有指定 edit_id 且查到資料，就顯示修改表單 -->
    <h2>修改寵物資料（ID：<?php echo htmlspecialchars($edit_data['id']); ?>）</h2> <!-- 顯示正在修改哪一筆 -->

    <form method="post" action=""> <!-- 修改表單，同樣用 POST 送回自己 -->
        <input type="hidden" name="action" value="update"> <!-- 隱藏欄位：此次動作是 update -->
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($edit_data['id']); ?>"> <!-- 隱藏欄位：要更新的 id -->

        <!-- Name：預設顯示原本資料 -->
        <label>
            Name：
            <input type="text" name="name" required
                   value="<?php echo htmlspecialchars($edit_data['name']); ?>">
        </label>
        <br><br>

        <!-- Owner：預設顯示原本資料 -->
        <label>
            Owner：
            <input type="text" name="owner" required
                   value="<?php echo htmlspecialchars($edit_data['owner']); ?>">
        </label>
        <br><br>

        <!-- Species：預設顯示原本資料 -->
        <label>
            Species：
            <input type="text" name="species" required
                   value="<?php echo htmlspecialchars($edit_data['species']); ?>">
        </label>
        <br><br>

        <!-- 性別：radio，根據原資料決定是否勾選 -->
        <label>
            Sex：
            <input type="radio" name="sex" value="m"
                <?php echo ($edit_data['sex'] === 'm') ? 'checked' : ''; ?>> m
            <input type="radio" name="sex" value="f"
                <?php echo ($edit_data['sex'] === 'f') ? 'checked' : ''; ?>> f
            <!-- 如果原本 sex 為空，就兩個都不勾 -->
        </label>
        <br><br>

        <!-- 出生日期：年 / 月 / 日，下拉並預設選原本的值 -->
        <label>
            Birth：
            <select name="birth_year">
                <option value="">年</option>
                <?php
                for ($y = 1990; $y <= 2026; $y++) {               // 產生 1990~2026 年
                    $selected = ($y == $edit_birthY) ? 'selected' : ''; // 如果這年等於原本出生年，就加 selected
                    echo "<option value=\"$y\" $selected>$y</option>";  // 輸出 option
                }
                ?>
            </select>

            <select name="birth_month">
                <option value="">月</option>
                <?php
                for ($m = 1; $m <= 12; $m++) {                    // 1~12 月
                    $selected = ($m == $edit_birthM) ? 'selected' : ''; // 如果等於原本出生月，就 selected
                    echo "<option value=\"$m\" $selected>$m</option>";  // 輸出 option
                }
                ?>
            </select>

            <select name="birth_day">
                <option value="">日</option>
                <?php
                for ($d = 1; $d <= 31; $d++) {                    // 1~31 日
                    $selected = ($d == $edit_birthD) ? 'selected' : ''; // 如果等於原本出生日，就 selected
                    echo "<option value=\"$d\" $selected>$d</option>";  // 輸出 option
                }
                ?>
            </select>
        </label>
        <br><br>

        <!-- 死亡日期：年 / 月 / 日，下拉並預設原本值，可留空 -->
        <label>
            Death（可空白）：
            <select name="death_year">
                <option value="">年</option>
                <?php
                for ($y = 1990; $y <= 2026; $y++) {               // 年份 1990~2026
                    $selected = ($y == $edit_deathY) ? 'selected' : ''; // 若等於原本死亡年就 selected
                    echo "<option value=\"$y\" $selected>$y</option>";  // 輸出 option
                }
                ?>
            </select>

            <select name="death_month">
                <option value="">月</option>
                <?php
                for ($m = 1; $m <= 12; $m++) {                    // 月份 1~12
                    $selected = ($m == $edit_deathM) ? 'selected' : ''; // 若等於原本死亡月就 selected
                    echo "<option value=\"$m\" $selected>$m</option>";  // 輸出 option
                }
                ?>
            </select>

            <select name="death_day">
                <option value="">日</option>
                <?php
                for ($d = 1; $d <= 31; $d++) {                    // 日期 1~31
                    $selected = ($d == $edit_deathD) ? 'selected' : ''; // 若等於原本死亡日就 selected
                    echo "<option value=\"$d\" $selected>$d</option>";  // 輸出 option
                }
                ?>
            </select>
        </label>
        <br><br>

        <button type="submit">更新</button> <!-- 送出修改 -->
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>">取消</a> <!-- 取消修改，回主畫面 -->
    </form>

    <hr> <!-- 分隔修改表單與下方列表 -->
<?php } ?> <!-- 修改表單 if 結束 -->

<!-- ======================= 資料列表（含「修改」按鈕） ======================= -->
<table width="100%" border="5" cellspacing="15" cellpadding="10"> <!-- 建立表格 -->
  <tbody> <!-- 表格主體 -->
    <tr> <!-- 標題列 -->
      <td>id</td>      <!-- 主鍵 id -->
      <td>name</td>    <!-- 寵物名 -->
      <td>owner</td>   <!-- 主人 -->
      <td>species</td> <!-- 物種 -->
      <td>sex</td>     <!-- 性別 -->
      <td>birth</td>   <!-- 出生日期 -->
      <td>death</td>   <!-- 死亡日期 -->
      <td>操作</td>    <!-- 操作欄（修改） -->
    </tr>

    <?php while($row = mysqli_fetch_assoc($result)) { ?> <!-- 逐筆取出資料列 -->
        <tr> <!-- 每一筆資料對應一列 -->
            <td><?php echo htmlspecialchars($row['id']); ?></td>      <!-- 顯示 id -->
            <td><?php echo htmlspecialchars($row['name']); ?></td>    <!-- 顯示 name -->
            <td><?php echo htmlspecialchars($row['owner']); ?></td>   <!-- 顯示 owner -->
            <td><?php echo htmlspecialchars($row['species']); ?></td> <!-- 顯示 species -->
            <td><?php echo htmlspecialchars($row['sex']); ?></td>     <!-- 顯示 sex -->
            <td><?php echo htmlspecialchars($row['birth']); ?></td>   <!-- 顯示 birth -->
            <td><?php echo htmlspecialchars($row['death']); ?></td>   <!-- 顯示 death -->
            <td>
                <!-- 修改連結：帶 edit_id 到同一支檔案，觸發上面的修改模式 -->
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>?edit_id=<?php echo $row['id']; ?>">
                    修改
                </a>
            </td>
        </tr>
    <?php } ?> <!-- while 迴圈結束 -->
  </tbody> <!-- 表格主體結束 -->
</table> <!-- 表格結束 -->

</body> <!-- 網頁主體結束 -->
</html> <!-- HTML 文件結束 -->